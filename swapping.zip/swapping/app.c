#include <stdio.h>

void main() {
float a,b;
a=5.6;
b=7.7;
a= a+b;
b=a-b;
a=a-b;
printf("after swapping %f %f",a,b);

}
