#include <stdio.h>

int main() {
float length,breadth;
printf("enter length and breadth");
scanf("%f %f", &length,&breadth );
printf("area of triangle is %f", length*breadth);




return 0;
}
