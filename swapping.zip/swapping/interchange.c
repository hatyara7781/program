#include <stdio.h>

void main() {
float a,b;
printf("enter two integres");
scanf("%f %f",&a,&b);
a= a+b;
b=a-b;
a=a-b;
printf("after swapping %f %f",a,b);
  










}
