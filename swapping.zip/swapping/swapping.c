#include <stdio.h>
void main() {
int num1,num2,num3,temp;
printf("enter two numbers");
scanf("%d %d",&num1,&num2);
temp = num1 ;
num1 = num2;
num2 = temp;
printf("after swaapping %d %d",num1 ,num2);
} 
c boiler



